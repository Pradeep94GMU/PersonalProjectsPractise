package com.example.Unique.username;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UniqueUsernameApplication {

	public static void main(String[] args) {
		SpringApplication.run(UniqueUsernameApplication.class, args);
	}

}
