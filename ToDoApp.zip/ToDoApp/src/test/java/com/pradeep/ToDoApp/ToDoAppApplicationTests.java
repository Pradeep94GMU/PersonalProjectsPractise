package com.pradeep.ToDoApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ToDoAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
