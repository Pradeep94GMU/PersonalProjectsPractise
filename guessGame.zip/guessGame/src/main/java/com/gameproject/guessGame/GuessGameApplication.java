package com.gameproject.guessGame;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GuessGameApplication {

	public static void main(String[] args) {
		SpringApplication.run(GuessGameApplication.class, args);
	}

}
